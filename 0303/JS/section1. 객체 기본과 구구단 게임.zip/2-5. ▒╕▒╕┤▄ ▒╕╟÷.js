// <2-5. 구구단 구현>

/*
//0 ~ 1.0값을 뽑음
console.log(Math.random())

//0 ~ 9.0
console.log(Math.random() * 9)

//소수점 내림 floor(소수점을 없앰)
//0~8
console.log(Math.floor(Math.random() * 9))


//Math.ceil(Math.random() * 9)가 더 깔끔 
//Math.ceil은 올림

//1~9
console.log( Math.floor(Math.random() * 9) + 1)
*/



// 반복문 2개사용
while (true) {
    var 숫자1 = Math.floor(Math.random() * 9) + 1
    var 숫자2 = Math.floor(Math.random() * 9) + 1
    var 결과 = 숫자1 * 숫자2
    var 조건 = true;
    while (조건) {
        var 답 = prompt(String(숫자1) + '곱하기' + String(숫자2) + '는?')
        if (결과 === Number(답)) {
            alert('딩동댕');
            조건 = false;      //정답을 맞출경우 컴퓨터가 문제를 다시 내야 하므로
        } else {
            alert('땡');    
        }
    }
}

//무한 반복문을 끄고 싶으면 shift+esc를 눌러 크롬 관리자 창에서 현재 탭을 종료