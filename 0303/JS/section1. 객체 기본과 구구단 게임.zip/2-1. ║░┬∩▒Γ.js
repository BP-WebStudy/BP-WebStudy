// <2-1. 별찍기(반복문 연습)
for (var star = 1; star <= 5; star += 1) {
    console.log('*')
} 
console.log()


//repeat()함수
for (var star = 1; star <= 5; star += 1) {
    console.log('*'.repeat(star))
}
console.log()


//거꾸로
for (var star = 5; star >= 1; star -= 1) {
    console.log('*'.repeat(star))
}
console.log()


//2개씩
for (var star = 10; star >= 2; star -= 2) {
    console.log('*'.repeat(star))
}
console.log()


//2배
for (var star = 1; star <= 16; star *= 2) {
    console.log('*'.repeat(star))
}
console.log()


// 공백과 별수를 따로 생각하기   
// 공백은 5 - star
for (var star = 5; star >= 1; star -= 1) {
    console.log(' '.repeat(5 - star) + '*'.repeat(star))
}
console.log()


// 공백은 0 1 2 3 4 로 되어야 하므로 9 - star 즉 0 2 4 6 8 을 2로 나눈다. 
for (var star = 9; star >= 1; star -= 2) {
    console.log(' '.repeat((9 - star) / 2) + '*'.repeat(star))
}
console.log()


// 보통 초기값은 0부터 시작한다.
// 0부터 시작하면 등호를 제외
// 0부터 시작하면 공백이 생김
for (var star = 0; star < 5; star += 1) {
    console.log('*'.repeat(star))
}
console.log()

// 0부터 시작하면 공백이 생기므로 star + 1을 해준다
for (var star = 0; star < 5; star += 1) {
    console.log('*'.repeat(star + 1))
}
console.log()


/* 숙제 for문 한번만 사용, 힌트 Math.abs
  *
 ***
*****
 ***
  *
*/
for (var star = 0; star < 5; star += 2){
    console.log(' '.repeat(5 - (star + 1)/2) + '*'.repeat(star + 1))
}

