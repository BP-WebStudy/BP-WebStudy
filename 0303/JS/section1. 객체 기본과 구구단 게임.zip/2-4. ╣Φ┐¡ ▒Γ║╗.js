// <2-4. 배열 기본>

//객체는 {}, 배열은 []

//값 그룹화는 하고 싶지만 속성 이름을 따로 주고 싶지는 않을 때 배열 사용
var 배열 = [
    '사과',
    '오렌지',
    '포도',
    '딸기',
]

console.log(배열[0])
console.log(배열[1])
console.log(배열[2])
console.log(배열[3])
console.log(배열[4])
console.log(배열[-1])
console.log(배열.length)
console.log(배열)


//
var 배열같은객체 = {
    0: '코끼리',
    1: '고양이',
    2: '강아지',
    3: '치킨',
    length: 4,
}
console.log(배열같은객체)

console.log(배열같은객체[0])
console.log(배열같은객체[1])
console.log(배열같은객체[2])
console.log(배열같은객체[3])
console.log(배열같은객체.length)


// Array.isArray
console.log(Array.isArray(배열))
console.log(Array.isArray(배열같은객체))

//
var 안녕 = '안녕하세요'
console.log(안녕[3])
console.log(안녕.length)
console.log(Array.isArray(안녕))


//
console.log(Boolean('true'))

/* 브라우저에서 기본적으로 제공하는 것들
Array
Math
Number
String
Boolean
window
document
*/
