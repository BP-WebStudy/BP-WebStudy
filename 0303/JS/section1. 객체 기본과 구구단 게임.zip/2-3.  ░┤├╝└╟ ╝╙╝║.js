// <2-3. 객체의 속성>

var 제로초 = {
    이름: '제로',
    먹다: function 먹다() {
        console.log('냠냠')
    },
}

//속성은 대괄호나 .으로 접근한다
console.log(제로초['이름'])
console.log(제로초['먹다'])
console.log(제로초.이름)
console.log(제로초.먹다())


//
console.log('*'.repeat(5))

//
var 문자객체 = {
    length: 5,
    repeat: function () {
        //함수 이름이 없어도 된다.
    }
}



//
var 네로 = {
    이름: '네로',
    키: 160,
    몸무게: 58,
}
console.log(네로)

//대괄호 안에는 변수를 쓸 수 있지만 점 뒤에는 안된다!
var 값 = '이름'
//console.log(네로.값)은 불가능!
console.log(네로[값])

//없는값을 입력시 undefined가 뜸
console.log(네로.나이)

//
네로.나이 = null
console.log(네로)

//속성을 지울 경우 null 사용
네로.키 = null
console.log(네로)

//null은 직접 지운것, undefined는 애초에 없던 값
