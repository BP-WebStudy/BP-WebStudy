// <1-12. else if>
// 조건문 if() {} else if() {} else {}

if (1*5 === 5){
    console.log('안녕')
} else {
    console.log('잘가')
}


//
var 변수 = false;
변수 = true;

if(변수) {
    console.log('안녕')
} else{
    console.log('잘가')
}


//
var 변수 = '포도';

if(변수 === '사과'){
    console.log('사과 좋아');
} else if(변수 === '오렌지'){
    console.log('오렌지 좋아');
} else if(변수 === '딸기'){
    console.log('딸기 좋아');
} else{
    console.log('과일 싫어');
}



//
var 변수 = '딸기';

if(변수 === '딸기'){
    console.log('딸기 좋아');
}
    console.log('과일 좋아');



//
var 변수 = '오렌지';

if(변수 === '딸기'){
    console.log('딸기 좋아');
}
    console.log('과일 좋아');




