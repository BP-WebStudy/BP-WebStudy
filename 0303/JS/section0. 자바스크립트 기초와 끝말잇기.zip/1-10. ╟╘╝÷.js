// <1-10. 함수>

// **는 제곱근

// ()부분이 입력값, return부분이 출력값
function 함수(x,z){
    return x+z+5;
}
console.log(함수(8,10));



// 함수는 반복되는 부분을 최소화 하기 위해 사용
function 더하기(첫째, 둘째) {
    return 첫째+둘째+3+5;
}
console.log(더하기(1,2));



//
function 인사(이름) {
    console.log('안녕하세요.')
    console.log(이름 + '님')
    console.log('반가워요')
}
console.log(인사('박지선'));
