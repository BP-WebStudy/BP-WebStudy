// <1-14. 끝말잇기 구현>

//word.length - 1 은 마지막단어를 가리킴
//alert()는 경고창띄우기
//prompt()는 입력창

var word = '제로초';
while(true){
    var answer = prompt(word)
    if (word[ word.length - 1 ] == answer[0]) {
        //맞았을 때
        alert('딩동댕');
        word = answer;
    } else{
        //틀렸을 때
        alert('땡');
    }
}


/* 같은코드 for문으로 바꾸기

for(var word='제로초초초'; true;){
    var answer = prompt(word);
    if (word[word.length - 1] === answer[0]){
        word = answer;
    } else{
        
    }
}
*/