/* <1-6. null, undefined> : 값이 저장x
undefined 대신 null을 쓰자.

' '는 빈값이 아니라 문자다!
''를 많이 쓴다.(''나 ""나 똑같다) 
*/

var name = "박지선"
name= "이정현" //변수가 기억하고 있는 값을 변경할 수 있다. (앞에 var없이 변경)
console.log(name) //("이정현" 이라고 나옴)
name = null //(name의 값을 없애줄 떄 null이라고 적어준다.)
console.log(name) //(null 라고 나옴)