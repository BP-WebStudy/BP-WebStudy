/* <1-8. 반복문(while)>
console.log()

while (조건) {

}
*/


/*
whilt (true) {
    console.log('안녕하세요')
}
//'안녕하세요' 무한반복
*/


//
var 값 = 0
while (값 < 100) {
    console.log('안녕하세요')
    값 = 값 + 1
}


//
var 값 = 0
while (값 < 5){
    console.log(값)
    값 = 값 + 1
}
//0 1 2 3 4 5
