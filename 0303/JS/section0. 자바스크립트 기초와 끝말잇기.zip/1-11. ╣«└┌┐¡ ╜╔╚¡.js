// <1-11. 문자열 심화>

/* 
자바스크립트는 숫자를 셀 때 0부터 시작
 함수야놀자
 0 1 2 3 4
*/
console.log('함수야놀자'[2]);
console.log('함수야놀자'[0]);



// 단어의 길이 .length
console.log('abcdefg'.length);

//
var 단어 = '함수야놀자';
console.log(단어);
console.log(단어[2]);
console.log(단어.length);

