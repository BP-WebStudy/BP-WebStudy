/* <1-7. 조건문 if>
if (조건) {
    
} else{

}
*/


if (5*5 === 25){
    console.log('딩동댕')
} else {
    console.log('땡')
}
// 실행결과는 조건이 true이므로 '딩동댕'이 출력된다.



//prompt는 사용자에게 입력을 받을 수 있다.
if (3*8 === prompt('답?')) {
    console.log('딩동댕')
} else {
    console.log('땡')
}
// 24를 입력시 '땡'이 나옴 (24가 문자이기 때문에 밑에 코드로 바꿔준다)
  

var 답 = prompt('답?')
if (3*8 === Number(답)) {
    console.log('딩동댕')
} else {
    console.log('땡')
}
//24를 입력시 '딩동댕'이 나옴
