// <1-9. 복습 & 연산자 심화>

console.log('문자1' + '문자2')   // '문자1문자2'
console.log('문자2' + 5)         //'문자25'
console.log('abc' + 'def')      //'abcdef'
console.log(String(5))          // 숫자가 문자5가 된다.
console.log(Number('5'))        // 문자가 숫자5가 된다.